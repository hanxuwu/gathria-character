# Side-view workspace candidate

Native 512x768 RGBA, 24 fps, anchor (256,710). Idle, walk and run loop; jump contains two consecutive original hops and holds a shallow crouch after landing. There is no automatic idle recovery. Mirror for left. Derived wardrobe needs this exact pack hash and its own frame registration; old wardrobe masks do not fit.
