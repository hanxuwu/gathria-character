# Keyframe loop study

CharacterPack V2; load all five archive files. Render listed rectangles without changing aspect ratio and honor the unchanged anchor. Animations list repeated frame IDs as deliberate holds at 24 FPS; do not deduplicate playback. All study actions loop, including the explicitly trimmed repeated hop. Original full jumps remain one-shot in the separate original packs. Left faces by mirror-x. Source RGBA copies remain native; no runtime drawing API or editor is needed. This pack is not a wardrobe layer kit.
