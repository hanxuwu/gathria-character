# CharacterPack V4: authored pixel artwork

Load manifest.json, character.json and every declared PNG. Page 0 is spritesheet; pages 1 onward are additionalSheets in order. additionalSheets may be empty. Every frame explicitly declares its page. Preserve the native rectangles, integer frame-relative anchor and aspect ratio.

Honor scale.pixelArt=true and scale.integerOnly=true: use nearest-neighbor sampling at positive integer display zoom. Do not smooth, quantize, normalize individual poses or resize exported artwork. A narrow viewport may scroll rather than shrinking below native size. Legacy V2/V3 consumers must explicitly reject V4.

Play frame IDs in their listed order at their declared FPS. Holds, missing actions and one-shot boundaries are intentional. A non-looping action holds its last frame unless the caller explicitly changes action. Native view is right; mirror left around the declared anchor.

This is a baked playback pack, not editable wardrobe layers or a skeleton. Artwork generation and source references must be honestly described in character.json and PROVENANCE.txt. No editor, model API or theme library is required to play this ZIP independently.

Limits: 1–4 atlas pages, 8192 pixels per dimension, 64 Mi decoded pixels per page, 128 Mi decoded pixels total, 1024 total grid cells, 64 MiB ZIP/aggregate PNG bytes and 256 KiB per text file.
