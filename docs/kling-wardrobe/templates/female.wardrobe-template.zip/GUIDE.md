# Kling female: offline clothing authoring kit

This kit contains the exact approved source CharacterPack, its native-frame
registration, and semantic authoring masks. It is **not** a dressed character,
not an editable wardrobe project, and not an automatic fitting model. Do not
upload this ZIP through the garment/project import control; use its files to
prepare a source-bound garment ZIP offline.

## Frozen visual and motion source

- Character: `kling-female-motion-v1`.
- Source CharacterPack SHA-256: `90a7d2a227910a399dabab805ac1a335240684c06d8d8eb57e88f236a5cbad23`.
- Exact registration JSON SHA-256: `c2b19a7a63aa40619babcc23eaa97d1673e79e82e6f8aa157a733869c7a2f953`.
- Native canvas: 704×1056.
- Attachment: (352, 998); native facing right.
- Unique source frames: 96.

Keep the approved head, face, proportions, shoulder/neck relationships and
source-frame positions. Do not change the body to fit a garment. Clothing can
intentionally cover a body region, but all source RGBA outside its declared
ownership must remain byte-for-byte unchanged. Source video pixels do not
contain the surfaces hidden under the original vest/shorts: newly exposed areas
need explicitly authored underpainting, with provenance. Do not claim that
these invisible body layers were accurately extracted from the video.

The `source.character.zip` bytes are unchanged. It contains the original PNG
atlas pages, manifest and recipe; the kit does not duplicate cropped source
frames. `frame-index.json` maps exact atlas frame IDs to page/rectangle,
original video frame number and timestamp. IDs are not consecutive counters.

| Action | Timeline entries | Unique poses | FPS | Playback |
| --- | ---: | ---: | ---: | --- |
| idle | 24 | 4 | 24 | loop |
| walk | 27 | 25 | 24 | loop |
| run | 16 | 16 | 24 | loop |
| jump | 39 | 39 | 24 | one-shot; hold last frame |
| celebrate | 16 | 12 | 24 | loop |

All five action frame lists are retained exactly. Repeated IDs are deliberate
holds. The jump is a complete one-shot, not a shortened loop. Clothing must
cover **every** unique source frame, including jump and celebration. Left
playback mirrors the whole character around the original attachment; it does
not mirror each garment around a separate origin.

## Registration and uncertainty

`registration.json` contains 17 native-coordinate landmarks per source frame:
`neck`, `nearShoulder`, `farShoulder`, `waistLeft`, `waistRight`, `nearHip`, `farHip`, `nearElbow`, `farElbow`, `nearWrist`, `farWrist`, `nearKnee`, `farKnee`, `nearAnkle`, `farAnkle`, `nearToe`, `farToe`.

The guides record visibility, confidence and derivation method. Hidden joints
and interpolated points are estimates, not original skeletal data. Inspect
these guides against each frame before preparing complex sleeves, trousers or
skirts. Registration changes must get a new SHA-256 and matching re-prepared
garments; never silently apply old clothes against changed anchors. Do not
substitute the different anchor from an older skeleton study.

Every frame includes a reviewed `head` protection polygon, and may include
`nearHand`/`farHand` polygons. The runtime checks native pixel centers, including
polygon boundaries. Garment ownership cannot intersect **nonzero-alpha source
pixels** inside those polygons; this preserves antialiased face/hand edges too.
The head protection includes the reviewed neck boundary. General skin masks
are not all foreground occluders: future sleeves may cover forearms, while
hands still need correct front/back ordering.

## Masks in this kit

`masks/<frameId>/<region>.png` contains native grayscale-L semantic guides.
Regions: `tank`, `shorts`, `skin`, `shoes`, `head`, `nearHand`, `farHand`, `nearArm`, `farArm`, `nearShoe`, `farShoe`.
For this kit, the female preparation's `headNeck` filename is normalized to
`head`; PNG contents are otherwise unchanged. Each file's hash, decode result,
pixel count and whether it contains partial coverage are in `inventory.json`.

These semantic guides describe **current visible material ownership**, not
finished new clothing. Some masks retain soft source alpha rather than binary
values. Empty near/far hand or arm masks are valid when that part is hidden.
The mask inventory explicitly records these empty regions. Do not assume a
mask is faulty merely because an occluded hand has no visible pixels.

Do not blindly reuse these mask PNGs as a runtime ownership bank. Final
ownership must have alpha exactly 0 or 255. It must include the old clothing to
replace, the authored new silhouette and any approved underpainting; exclude
the protected head/foreground hands and resolve near/far limb ordering for the
actual pose. A semantic segmentation or anchor location is a review aid, not
proof that garment contours will fit.

## Build a real garment pose bank

1. Design the clothing offline in the same view, scale, lighting and drawing
   style. Record the art source/tool, prompt, processing and hidden-surface
   reconstruction. A single standing PNG cannot automatically fit every pose.
2. Prepare a native RGBA patch plus binary ownership for each exact frame ID.
   Keep cloth/cuff/joint overlaps stable; add pose-specific art where simple
   deformation cannot preserve a folded sleeve, trouser knee or skirt volume.
3. Decide occlusion explicitly. The near hand may cover a shirt; a long dress
   may cover shoes; a far arm may be behind the torso. Prepare the final patch
   accordingly rather than relying on one global foreground-color deletion.
4. Crop and pack matching patch/ownership atlases. Both use the same rectangle;
   its integer `offset` places it in the unchanged native source frame. At
   ownership=255 the compositor **replaces all RGBA channels**, including alpha
   zero for old-cloth removal. At ownership=0 the patch must be transparent and
   the original source pixel remains exact. This is not source-over blending.
5. Create a `gathria-sprite-garment`, version 1, manifest with source/registration
   hashes, stable item ID/name, slot, pages, every frame and truthful provenance.
   See the repository's `docs/kling-wardrobe/FORMAT.md` and
   `scripts/kling_wardrobe_common.py::save_garment` for the implemented format.
6. Import through the wardrobe garment control. Examine native/2× stills and
   full idle/walk/run/jump/celebrate playback in both directions. Compare to the
   source frame, checking head/neck, armpits, hands, waist, crotch, knees, hems
   and ankles. Validate all supported slot combinations, not just a hero pose.
7. Save a self-contained wardrobe project and export a baked CharacterPack.
   Close the editor and load the baked pack in the independent player. Passing
   hashes and coverage checks does not constitute visual acceptance.

## Slots, limits and compatibility

Slots: `top`, `bottom`, `fullBody`, `shoes`. A full-body outfit excludes top and
bottom; shoes remain independent. Composition order is shoes → bottom → top →
fullBody so cuffs/hem can cover footwear. Nullable slots retain source clothing.
Items are compatible only with this exact source and registration, not every
character with a similar name. Missing poses fail; they do not silently show
original clothing. New garment revisions need distinct stable IDs.

Garments allow up to four atlas pages, each dimension ≤8192, with ≤32 Mi pixels
total per patch bank and matching ownership bank; garment ZIP ≤64 MiB. An
editable wardrobe project embeds source/registration and at most 16 garments
within 128 MiB. Baked CharacterPack limits remain unchanged: ≤64 MiB ZIP and
V3 ≤4 pages/128 Mi decoded pixels/1024 cells. Use tighter crop packing rather
than changing the source canvas or bypassing limits.

## Reproducing preparation

The reviewed preparation environment was CPython 3.12.14, Pillow 12.3.0,
numpy 2.3.5, scipy 1.17.0 and opencv-python-headless 5.0.0.93
(`cv2.__version__` reports 5.0.0). The exact package pins are included as
`requirements.txt` and tracked in `scripts/requirements-kling-wardrobe.txt`.

Use those dependencies in a dedicated environment when regenerating anchors
or semantic masks. This execution used OpenCV from
`PYTHONPATH=/tmp/kling-wardrobe-python`; that temporary installation path is
not a runtime dependency of the kit or character. A normal virtual environment
with the pinned packages avoids relying on that directory. The packaging
builder alone needs Python and Pillow; it copies the supplied masks and source
bytes without re-running optical flow or inventing missing art. Different
preparation algorithms or numerical-library builds may produce new masks;
review them and rebuild hash-bound garments instead of asserting compatibility.

The repository's `docs/kling-wardrobe/templates/README.md` gives exact commands
and temporary output paths. Male preparation automatically finishes with
`scripts/refine-kling-wardrobe-male-masks.py`, applying the source-bound reviewed
contours in `artwork/kling-wardrobe/registration/male/reviewed-mask-corrections.json`.
Retain that step when reproducing the male masks; the verified local shoe
ownership cannot be replaced with a generic color threshold. The refinement
checks source and registration identity without changing source pixels or joints.

`inventory.json` hashes every delivered payload except itself. This kit is a
reproducible authoring reference; it does not promise seamless arbitrary new
clothing or repair pose transitions already present in the original source.
