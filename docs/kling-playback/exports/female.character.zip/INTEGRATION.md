# CharacterPack V2: baked source playback

Load manifest.json and spritesheet.png; read character.json as a gathria-baked-character recipe, not a legacy character appearance configuration.

Render each referenced frame rectangle at its native aspect ratio. The PNG is 8-bit RGBA with smooth alpha. Honor scale.pixelArt=false and scale.integerOnly=false; use smooth image sampling for a fractional display scale. The recommended scale is only a viewing preference, never a change to exported source pixels.

Use each animation's frame IDs in their listed order at its declared FPS. Repeated IDs are deliberate holds. Honor loop; a non-looping action stops on its final frame. celebrate and jump are distinct actions. Disable unavailable actions rather than inventing substitutes.

The native view is right; left is a horizontal mirror. Apply the declared frame-relative anchor consistently. These source clips contain their authored in-frame motion; do not normalize individual poses or add world displacement unless your scene explicitly requests it.

This pack supports baked playback only (editableAppearance=false). It does not contain a reusable skeleton, wardrobe layers, or a claim that missing/occluded source detail was reconstructed. Source provenance and selection are in character.json and PROVENANCE.txt. Runtime playback requires neither the editor nor a model API.

Limits: 8192 pixels per sheet dimension, 64 Mi pixels decoded, at most 1024 unique frames, 64 MiB ZIP/PNG and 256 KiB per text file. Legacy V1 packs keep their original 4096-pixel/32-MiB limits and integer pixel rendering.
