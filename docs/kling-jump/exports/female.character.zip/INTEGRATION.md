# CharacterPack V3: multipage original artwork

Load manifest.json, character.json and every declared PNG. Page 0 is spritesheet; pages 1 onward are additionalSheets in order. Each frame has an explicit page index and an unscaled rectangle within that page. All pages share native frame dimensions and the frame-relative anchor. Do not combine pages into an oversized image or resize artwork.

Play each animation's frame IDs in order at its declared FPS. Respect loop: a one-shot jump holds its last frame and can be explicitly replayed. Jump and celebrate remain distinct. Missing actions are unavailable. Render right natively and left with mirror-x around the anchor. Fractional display zoom uses smooth sampling; exported pixels stay native.

This baked recipe is not editable wardrobe or skeletal data. Provenance and source frame/timing maps are in character.json. The complete ZIP supports independent playback. A single PNG with metadata cannot represent V3. Older V1/V2-only consumers must reject schemaVersion 3 explicitly.

Limits: 2–4 PNG pages, each at most 8192 pixels per dimension and 64 Mi pixels decoded; at most 128 Mi decoded pixels across all pages, 1024 total grid cells/unique frames, 64 MiB ZIP/aggregate PNG bytes, 256 KiB per text file. V1/V2 limits and file envelopes remain unchanged.
