# Clothing variant authoring kit

This kit contains the exact selected clothing, its source-bound anchors and a
versioned recipe. It is not a CharacterPack or a ready-to-import garment.

1. Extract this ZIP. Keep base.garment.zip and registration.json unchanged.
2. Edit recipe.json: give the output a new id/name. Optional material rules use
   sourceRgb, targetRgb and tolerance (see the repository recipe guide).
3. For a difficult pose, add a frameId plus SHA-256-bound image and mask files
   to poseOverrides. Paint at the native 704 × 1056 frame size.
   Masks are binary grayscale PNGs; paint only inside existing clothing ownership
   and preserve alpha. Frame crop offsets are in the base garment manifest.
4. From a checkout of gathria-character with the artwork Python dependencies:
   python scripts/build-kling-garment-variant.py /path/to/kit/recipe.json --root /path/to/kit --output /path/to/new-item.zip
5. Use Import clothing in the same character's wardrobe, then inspect all five
   actions in both directions. Save wardrobe and export CharacterPack separately.

The unchanged source/registration hashes prevent applying this clothing to the
other body or an incompatible source revision. There is no automatic fitting of
one standing PNG. New sleeve lengths or silhouettes require the full authoring
template and explicit ownership review. No source face/body pixels are edited.
Full guide: docs/kling-refinement/recipes/README.md in the repository.
