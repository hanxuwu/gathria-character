# CharacterPack V3: baked wardrobe playback

Load manifest.json, character.json and every declared spritesheet PNG. Page 0 is spritesheet; additionalSheets, when present, follow in order. Each frame uses its explicit page and native rectangle. Preserve the frame-relative anchor and aspect ratio. Exported frames are RGBA with smooth transparency; scale.pixelArt=false.

Play action frame IDs in their listed order at the declared FPS. Repeated IDs are intentional holds. Respect loop=false for one-shot actions, and disable missing actions. Native view is right; left mirrors the complete character around the anchor. The original authored in-frame movement and optional motionFlow metadata are retained. Do not independently recenter clothing or normalize jumping frames.

Clothing is already composited into these PNGs. capabilities.editableAppearance=false is intentional: this ZIP is standalone playback, while a gathria-wardrobe-project ZIP contains the original source, registration and editable garments. This pack does not depend on that project, the editor, a skeletal renderer or a model API. Provenance in character.json distinguishes original video artwork from authored garment patches.

Limits: up to 4 sheets, 8192 pixels per dimension, 128 Mi decoded pixels total, 1024 frame cells, 64 MiB CharacterPack ZIP and 256 KiB per text file.
