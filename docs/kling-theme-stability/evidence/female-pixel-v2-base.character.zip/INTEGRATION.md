# CharacterPack V4: authored pixel artwork

Load manifest.json, character.json and every declared atlas PNG. Page 0 is spritesheet; additionalSheets may be empty. Each frame has an explicit page and an unscaled rectangle. Preserve the native 192 x 272 frame and the frame-relative anchor (96, 251).

Honor scale.pixelArt=true and scale.integerOnly=true: render with nearest-neighbor sampling at a positive integer zoom. Do not smooth, normalize separate poses or resize exported artwork. V2/V3-only consumers must explicitly reject V4.

Play the listed frame IDs at each animation's declared FPS. Repeated IDs are intentional holds. Honor loop; the one-shot jump stops on its last frame until explicitly replayed or another action is selected. The native direction is right; mirror horizontally around the declared anchor for left. These clips animate in place, without world displacement.

This is a complete baked look for independent playback, not editable garment layers or a skeleton. Source artwork, identity, registration and timing are described in character.json and PROVENANCE.txt. The editor and theme catalog are not needed to play this CharacterPack.
