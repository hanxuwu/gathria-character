# Side-view selection candidate

Play at declared 24 fps. Mirror around the fixed anchor for left. Jump and celebration play once and hold their final source pose; replay explicitly. No automatic idle return or motion-flow routes have been fabricated. Loop candidates are reviewed selections, not guarantees of a seamless transition between actions. See character.json for each source and registration. Existing wardrobe assets belong to old poses and are not compatible with these baked frames.
