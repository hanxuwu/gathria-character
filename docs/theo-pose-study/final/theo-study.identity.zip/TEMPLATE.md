# Theo pose study — registered character identity

Every artwork and mask uses a 192×256 transparent canvas. Shared foot anchor (96,240), neck registration (96,118), source jaw binding and head placement must remain consistent across all three expressions. Heads include their face, ears, front hair and neck; optional back-hair is drawn behind the body. No clothing or limbs belong to this package.

Masks are semantic data: RGB (material,0,0), with 0=fixed eyes/outlines/accessories, 1=skin, 2=hair. Match artwork alpha exactly using only 0 or 255; transparent pixels have zero RGBA. Keep all parts on the identity's declared source skin/hair palette. Changing a source color requires changing its matching sourceAppearance reference. Identity source colors preserve the authored pixels exactly; choosing another skin/hair color applies deterministic mask recoloring.

Keep the three complete expression heads, registered neck and actor silhouette stable. Do not move heads independently to fit expressions. Do not add archive paths. Use a new custom- identifier, preserve creator/license information and record edits before importing a new character. Current provenance: Development image-generation complete-pose-model.png, original source identity and unchanged uniform source registration. Study preparation in scripts/prepare-theo-pose-study.mjs. No runtime generation.
