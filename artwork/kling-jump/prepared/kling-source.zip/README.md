# Original Kling source frames

Zero-based decoded video frame indices. Every selected frame is played forward once at the original 24 fps; no duplicated endpoint, ping-pong, interpolation or morphing.
Fixed per-character crop only. No scaling, per-frame recentering, stabilization, skeleton fitting, repainting or facial correction.
Ground anchor is a fixed reference near the standing soles, not a per-frame foot lock or anatomical measurement.
Background alpha is estimated from each source green-screen profile. Only partially transparent edge RGB is unmixed/despilled; every fully opaque pixel retains decoded source RGB exactly.
Original source motion blur, pose variation and small cycle mismatch remain visible. These are reviewed loop candidates, not user-approved final animation.
Jump is a single forward performance, source frames171–209 inclusive at24fps, then holds its final frame. No celebration frames substitute for jump.
All frames gain32 transparent canvas pixels above the old crop; anchor moves by the same32pixels. Existing four actions retain identical RGBA after removing this padding. No visible artwork is shifted relative to its anchor.
The original videos cut a small scalp arc at source frames183–186. New canvas includes every source pixel but cannot reconstruct artwork missing from the video.
