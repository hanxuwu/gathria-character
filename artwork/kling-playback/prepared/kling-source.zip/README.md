# Original Kling source frames

Zero-based decoded video frame indices. Every selected frame is played forward once at the original 24 fps; no duplicated endpoint, ping-pong, interpolation or morphing.
Fixed per-character crop only. No scaling, per-frame recentering, stabilization, skeleton fitting, repainting or facial correction.
Ground anchor is a fixed reference near the standing soles, not a per-frame foot lock or anatomical measurement.
Background alpha is estimated from each source green-screen profile. Only partially transparent edge RGB is unmixed/despilled; every fully opaque pixel retains decoded source RGB exactly.
Original source motion blur, pose variation and small cycle mismatch remain visible. These are reviewed loop candidates, not user-approved final animation.
